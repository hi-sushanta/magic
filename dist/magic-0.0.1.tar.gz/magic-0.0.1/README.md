# Magic
One package open your gate to using different type GAN Network.